

/**
 * Created with IntelliJ IDEA.
 * User: tomas
 * Date: 4/9/14
 * Time: 10:48 PM
 * To change this template use File | Settings | File Templates.
 */
public enum TaskType {

    voluntaryTask,
    stretchTask,
    strictTask,
    midtermTask;

}
